-In order to run the program outside of an IDE run table.java from the command prompt to begin the program.

It is located in pokerAssistant>src>pokerAssistant