package pokerAssistant;

public class Card {

	int suit;			// 0 = Clubs, 1 = Diamond, 2 = Hearts, 3 = Spades
	int face_value;		// Ace = 13
	
	// Constructor for Card class
	public Card(int suitIn, int face_valueIn) {
		suit = suitIn;
		face_value = face_valueIn;
	}
	
}
