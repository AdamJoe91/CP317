package pokerAssistant;

import java.lang.*;
import java.util.*;

public class Bots extends Player {
	public Bots(ArrayList<Card> handIn, float balanceIn, float betIn, boolean bigBlindIn, boolean smallBlindIn,
			boolean dealerIn, String statusIn) {
		super(handIn, balanceIn, betIn, bigBlindIn, smallBlindIn, dealerIn, statusIn);
		hand = handIn;
		balance = balanceIn;
		bet = betIn;
		bigBlind = bigBlindIn;
		smallBlind = smallBlindIn;
		dealer = dealerIn;
		status = statusIn;

	}
}
