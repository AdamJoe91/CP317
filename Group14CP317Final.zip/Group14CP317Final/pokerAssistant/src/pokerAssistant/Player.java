package pokerAssistant;

import java.util.ArrayList;
import java.util.Collections;

public class Player {
	ArrayList <Card> hand;
	float balance;
	float bet;
	boolean bigBlind;
	boolean smallBlind;
	boolean dealer;
	String status; //fold call, check, raise, allIn
	int handStrength;
	
	
	public Player(ArrayList <Card> handIn,float balanceIn,float betIn, boolean bigBlindIn,boolean smallBlindIn, boolean dealerIn,String statusIn) {
		hand = handIn;
		balance = balanceIn;	
		bet = betIn;
		bigBlind = bigBlindIn;
		smallBlind = smallBlindIn;
		dealer = dealerIn;
		status = statusIn;
		handStrength = 0;
		
	}
	
	public void print() {
		/* =============================================================
		 * Prints all the cards in a Player object's hand
		 * =============================================================
		 * Preconditions:
		 * 
		 * Postconditions:
		 * 		All cards are printed to console
		 * =============================================================
		 */ 
		
		for (int j = 0; j < this.hand.size(); j++) {
			System.out.print("(" + this.hand.get(j).suit + ", ");
			System.out.print(this.hand.get(j).face_value + ")     ");
		}
		
		System.out.println("");
		return;
	}

	public void add_card(ArrayList<Card> cardsInPlay) {
		/* =============================================================
		 * Adds two cards to this Player's hand
		 * =============================================================
		 * Preconditions:
		 * 		cardsInPlay - ArrayList<Card> containing all cards in circulation
		 * Postconditions:
		 * 		Player.hand receives two new cards
		 * =============================================================
		 */ 
		this.hand.add(TableFunctions.dealCard(cardsInPlay));
		this.hand.add(TableFunctions.dealCard(cardsInPlay));
		
		return;
	}


	public void firstBotChoice(Player BotActive, float bet) {

		// Worst Possible Starting hand so fold
		if (BotActive.hand.get(0).face_value == (6) && BotActive.hand.get(0).face_value == 1) {
			BotActive.status = "fold";
			return;
		}
		// Reverse of above statement
		else if (BotActive.hand.get(0).face_value == (6) && BotActive.hand.get(1).face_value == 1) {
			BotActive.status = "fold";
			return;
		}

		// Checks for what is generally considered a bad hand, folds if hand is bad.

		// Checks if a pair in player hand
		else if (BotActive.hand.get(0).face_value == BotActive.hand.get(1).face_value) {

			// if pocket aces raise the bet even higher (Best Possible Hand)
			if (BotActive.hand.get(0).face_value == 12) {
				BotActive.status = "bet";
				BotActive.bet = (BotActive.balance / 5);
				return;
			}

			BotActive.status = "bet";
			BotActive.bet = (BotActive.balance / 10);
			return;
		}

		else if (BotActive.hand.get(0).face_value + BotActive.hand.get(1).face_value < 10
				&& Math.abs(BotActive.hand.get(0).face_value - BotActive.hand.get(1).face_value) < 10) {
			BotActive.status = "fold";
		}

		else {
			BotActive.status = "call";
		}

	}

	public void tableBotChoice(Player BotActive, ArrayList<Card> cardsInPlay, float potAmount, float bet) {
		//move from best hand to worst
		//
		boolean play = false;
		
		//checks the strength of hands from strongest to worst
		//if a strong hand is found disregard any weaker options
		//disregard because strong hands contain weaker ones, we only want strongest hand
		play = checkRoyalFlush(BotActive,cardsInPlay,potAmount);
		if(!play) {
			play = checkStraightFlush(BotActive, cardsInPlay);//works
			if(!play) {
				play = check4Kind(BotActive,cardsInPlay,potAmount);//works
				if(!play) {
					play = checkFullHouse(BotActive,cardsInPlay);//works
					if(!play) {
						play = checkFlush(BotActive,cardsInPlay,potAmount);//works
						if(!play) {
							play = checkStraight(BotActive,cardsInPlay,potAmount);//works
							if(!play) {
								play = check3Kind(BotActive,cardsInPlay,potAmount);//works
								if(!play) {
									play = check2Pair(BotActive,cardsInPlay);//works
									if(!play) {
										play = checkPair(BotActive,cardsInPlay,potAmount);//works
									}
								}	
							}				
						}
					}	
				}
			}
		}
		
		// Have bots remove them selves from the game when their balance gets to low
		if (BotActive.balance <= 50) {
			BotActive.bet = BotActive.balance;
			BotActive.status = "allIn";
		} 
		
		if (!play) {
			if (bet == 0) {
				BotActive.status = "check";
			} else {
				BotActive.status = "fold";
			}
		}
		
	}
	
	public boolean check2Pair(Player BotActive, ArrayList<Card> cardsInPlay) {
		
		//initalize arraylist and populate with all cards in play and player hand
		ArrayList<Integer> check = new ArrayList<>();
		check.add(BotActive.hand.get(0).face_value);
		check.add(BotActive.hand.get(1).face_value);
		//integer used to track first pair found as to not count double hands
		//99 used as default value because its an impossible number to reach
		int firstPairValue =99;
		for(int i =0; i<cardsInPlay.size();i++) {
			check.add(cardsInPlay.get(i).face_value);
		}
		
		//sort to make it easier to check for pairs
		Collections.sort(check);
		//use boolean to check whether or not a singular pair is found
		
		boolean firstPairCheck = false;
		//loop to search for first pair
		//set pair check value to whatever this pair is, change firstPairCheck to true so we can check for second pair
		for(int i =1 ; i<check.size();i++) {
			if(check.get(i)==check.get(i-1)) {
				firstPairCheck = true;
				firstPairValue = check.get(i);
		
			}
			
		}
		
		if(firstPairCheck) {
			
			//check for second pair where the value is not the same as the 1st pair
			//if it is then a 2 pair occurs, update bot information to reflect this
			for(int i =1 ; i<check.size();i++) {
				if(check.get(i)==check.get(i-1)&& check.get(i)!= firstPairValue) {
					BotActive.status = "raise";
					BotActive.bet = BotActive.balance/10;
					BotActive.handStrength = 2;
					return true;
				}
			}
			
		}
		//if the above is false then return and move to next check
		else {
			return false;
		}
		return false;
		
		
	}
	public boolean check3Kind(Player BotActive,ArrayList<Card> cardsInPlay, float potAmount) {
		//initialize arraylist to contain all cards in play and player hand
		ArrayList<Integer> check = new ArrayList<>();
		check.add(BotActive.hand.get(0).face_value);
		check.add(BotActive.hand.get(1).face_value);
		
		for(int i =0; i<cardsInPlay.size();i++) {
			check.add(cardsInPlay.get(i).face_value);
		}
		//count values to keep track of 3 of a kind
		//start at 1 because by default there will always be at least 1 card of 'x' face value (the card being examined)
		int count = 1;
		int maxCount = 1;
		//initalize a previous value in order to check all values and avoid outofbounds in loop
		int previousValue = check.get(0);
		//sort check to make the analysis for 3 of a kind easier
		Collections.sort(check);
		
		//checks for pairs of cards and adds to a count value
		//if a new card is found that does not match then restart count at 1
		for(int i =1;i<check.size();i++) {
			if(check.get(i)==previousValue) {
				count++;
			}
			//takes the highest count value in case of a change of face value to be later evaluated 
			if(count>maxCount) {
				maxCount=count;
			}
			if(check.get(i)!=previousValue) {
				previousValue = check.get(i);
				count = 1;
			}
			
		}
		//check if three same value cards have been found
		if(maxCount ==3) {
			BotActive.status = "raise";
			BotActive.bet = BotActive.balance/7;
			BotActive.handStrength = 3;
			return true;
		}
	return false;		
	}
	
	public boolean checkFullHouse(Player BotActive, ArrayList<Card> cardsInPlay) {
		
		//initialize array to hold all cards in play and player hand
		ArrayList<Integer> check = new ArrayList<>();
		check.add(BotActive.hand.get(0).face_value);
		check.add(BotActive.hand.get(1).face_value);
		
		for(int i =0; i<cardsInPlay.size();i++) {
			check.add(cardsInPlay.get(i).face_value);
		}
		
		//FullHouse contains a three of a kind and a pair
		//initalize a value to hold the first check(three of a kind) to avoid overlap with same numbers when checking for a pair
		//use 99 as initial value becuase it does not represent a possible face value
		int threeOfAKindValue =99;
		boolean threeofAKind = false;
		//sort to make checking easier
		Collections.sort(check);
		
		//loop to determine if the three of a kind exists
		//if it does update the value and boolean check to reflect that
		for(int i =1; i<check.size()-1;i++) {
			if(check.get(i)==check.get(i-1) &&check.get(i)==check.get(i+1)) {
				threeOfAKindValue = check.get(i);
				threeofAKind = true;
			}
		}
		
		//if three of a kind exists check for a pair where it does not share the face value with three of a kind
		//if true update bot information to reflect that
		if(threeofAKind) {
			for(int i =1; i<check.size();i++) {
				if(check.get(i)==check.get(i-1)&&check.get(i)!=threeOfAKindValue) {
					
					BotActive.status = "raise";
					BotActive.bet = BotActive.balance/2;
					BotActive.handStrength = 6;
					return true;
				}
			
			}
		}
		else {
			return false;
		}
		return false;
	}
	

	public boolean checkStraightFlush(Player BotActive, ArrayList<Card> cardsInPlay) {
		//initalize two array lists
		//one of face values to check for straight
		//the other of suits to check for flush requirement
		ArrayList<Integer> check = new ArrayList<>();
		check.add(BotActive.hand.get(0).face_value);
		check.add(BotActive.hand.get(1).face_value);
		for(int i =0; i<cardsInPlay.size();i++) {
			check.add(cardsInPlay.get(i).face_value);
		}
		
		
		ArrayList<Integer> checkSuit = new ArrayList<>();
		checkSuit.add(BotActive.hand.get(0).suit);
		checkSuit.add(BotActive.hand.get(1).suit);
		
		for(int i =0; i<cardsInPlay.size();i++) {
			checkSuit.add(cardsInPlay.get(i).suit);
		}
		
		

		//sort both array lists to make checks on each easier
		Collections.sort(check);
		Collections.sort(checkSuit);
		//intialize count values at 1 to check for straight and flush
		//start at 1 becuase there will always be 1 of the highest possible value (the card being analyzed)
		int count = 1;
		int maxSuit = 1;
		for(int i = 1;i<check.size();i++) {
			if(Math.abs(check.get(i)-check.get(i-1))==1) {
				count++;
			}
			else {
				count = 1;
			}
		}
		//if there is not 5 in a row then the conditions cannot be met.
		if(count<5) {
		
			return false;
		}
		
		else {
			int suitCount = 1;
			//loop to check if the flush condition is met
			for(int i = 1;i<checkSuit.size();i++) {
				if((checkSuit.get(i)==checkSuit.get(i-1))) {
					suitCount++;
				}
				else {
					suitCount = 0;
				}
				
				maxSuit = Math.max(suitCount, maxSuit);
			}
			
		}
		//if the flush condition is met then the straight flush occurred
		//we only check for flush if straight has occurred
		if(maxSuit == 5) {
			float betValue = (float) 0.9;
			BotActive.status = "raise";
			BotActive.bet = BotActive.balance*betValue;
			BotActive.handStrength = 8;
			return true;
		}
			
		return false;
		
	}
	
	public boolean check4Kind(Player BotActive,ArrayList<Card> cardsInPlay, float potAmount) {
		//initalize arraylist to keep track of face values of cards in play and player hand
		ArrayList<Integer> check = new ArrayList<>();
		check.add(BotActive.hand.get(0).face_value);
		check.add(BotActive.hand.get(1).face_value);
		
		for(int i =0; i<cardsInPlay.size();i++) {
			check.add(cardsInPlay.get(i).face_value);
		}
		//sort to make checking easier
		Collections.sort(check);
		//intialize counts at 1 because there will always be a value of 1 (card being analyzed)
		int count = 1;
		int maxCount = 1;
		int previousValue = check.get(0);
		//check for 4 cards of same face value, update count if cards have equal face values
		//if a higher count is found, when a new face value occurs over write the highest count
		for(int i =1;i<check.size();i++) {
			if(check.get(i)==previousValue) {
				count++;
			}
			if(count>maxCount) {
				maxCount=count;
			}
			if(check.get(i)!=previousValue) {
				previousValue = check.get(i);
				count = 0;
			}
			
		}
		//if there are 4 of the same face value then 4 of a kind achieved
		//update player info to reflect this.
		if(maxCount ==4) {
			BotActive.status = "raise";
			BotActive.bet = BotActive.balance/4;
			BotActive.handStrength = 7;
		
			return true;
		}
	return false;		
	}
	public boolean checkFlush(Player BotActive,ArrayList<Card> cardsInPlay, float potAmount) {
		//initalize arraylist to track suit of playercards as well as cardsinplay
		ArrayList<Integer> checkSuits = new ArrayList<>();	
		checkSuits.add(BotActive.hand.get(0).suit);
		checkSuits.add(BotActive.hand.get(1).suit);
		for(int i =0; i<cardsInPlay.size();i++) {
			checkSuits.add(cardsInPlay.get(i).suit);
		}
		//sort to make check easier
		Collections.sort(checkSuits);
		//count variable to look for same suits
	
		int count = 1;
		int maxSuit = 1;
		int previousSuit = checkSuits.get(0);
		for(int i =1;i<checkSuits.size();i++) {

			
			if(checkSuits.get(i)==previousSuit) {
				count++;
			}
			else {
				previousSuit = checkSuits.get(i);
			}
			maxSuit = Math.max(count, maxSuit);
		}
		//if there are 5 of the same suit then the condition for the flush has been met
		//update player info to reflect this.
		if (maxSuit == 5) {
			
			BotActive.status = "raise";
			BotActive.bet = BotActive.balance/3;
			BotActive.handStrength = 5;
			
			return true;
		}
		else {
		
			return false;
		}

	}
	public boolean checkStraight(Player BotActive,ArrayList<Card> cardsInPlay,float potAmount) 
	{
		int count = 1;
		ArrayList<Integer> checkStraight = new ArrayList<>();
		checkStraight.add(BotActive.hand.get(0).face_value);
		checkStraight.add(BotActive.hand.get(1).face_value);
		
		for(int i =0;i<cardsInPlay.size();i++) {
			checkStraight.add(cardsInPlay.get(i).face_value);
		}
		Collections.sort(checkStraight);
		
		for(int i = 1;i<checkStraight.size();i++){
			if(Math.abs(checkStraight.get(i)-checkStraight.get(i-1))==1) {
				count++;
			}
			else {
				count = 0;
			}
		}
		if(count<5) {
			return false;
		}
		//check for suits
		if (count>=5) {
			BotActive.status = "raise";
			BotActive.bet = BotActive.balance/2;
			BotActive.handStrength = 4;
			
			return true;
		}
		
		return false;
		
	}
	public boolean checkRoyalFlush(Player BotActive, ArrayList<Card> cardsInPlay, float potAmount) {
		//check if all values are 13,12,11,10,9 and same suit
		
		//array list used to sort values to check for "Royal"
		ArrayList<Integer> checkFlush = new ArrayList<>();
		//will ensure that a "flush is occuring, use value 10 to differentiate between having no "Ace" which is the basis for check.
		int suitToCheck =10;
		
		//checks cardsInPlay for Ace
		checkFlush.add(BotActive.hand.get(0).face_value);
		checkFlush.add(BotActive.hand.get(1).face_value);
		
		//check if player has Ace in hand, if they do set that to the check for suit
		if(BotActive.hand.get(0).face_value == 12) {
			suitToCheck = BotActive.hand.get(0).suit;
		}
		else if(BotActive.hand.get(1).face_value == 12) {
			
				suitToCheck = BotActive.hand.get(1).suit;
			
		}
		
		//if any card is an ace thats in play set that to be the suit to check
		for(int i = 0; i<cardsInPlay.size();i++) {
			
			if(cardsInPlay.get(i).face_value==12) {
				suitToCheck = cardsInPlay.get(i).suit;
			}
		}
		
		//if there was no ace found return false
		if (suitToCheck == 10){
			return false;
		}
		
		
		//add all cards to an array to check if there is the correct face values of cards
		for(int i = 0; i<cardsInPlay.size();i++) {
			if(cardsInPlay.get(i).suit == suitToCheck) {
				checkFlush.add(cardsInPlay.get(i).face_value);
			}
			else {
				
				checkFlush.add(20);
			}
		}
		
		Collections.sort(checkFlush);
		Collections.reverse(checkFlush);
		//these values will always be checked for because the conditions are never changing, they are a set face value with the same suit
		if(checkFlush.get(0) != 12) {
			return false;
		}
		else if (checkFlush.get(1)!=11){
			return false;
		}
		else if (checkFlush.get(2)!=10) {
			return false;
		}
		else if (checkFlush.get(3)!=9) {
			return false;
			
		}
		else if (checkFlush.get(4)!=8) {
			return false;
		}
	
	BotActive.status = "allIn";
	BotActive.handStrength = 9;
	return true;
		
	}
	public boolean checkPair(Player BotActive, ArrayList<Card> cardsInPlay, float potAmount) {
		//check if player hand contains a pair
		if(BotActive.hand.get(0).face_value==BotActive.hand.get(1).face_value) {
			//because a pair is a relatively week hand if the risk is too great then ignore the pair and 'fold' the hand
			if (potAmount < BotActive.balance / 5) {
				BotActive.bet = BotActive.balance / 10;
				BotActive.status = "raise";
				BotActive.handStrength = 1;
				return true;
			} else {
				BotActive.status = "fold";
				
				return true;
			}
		}
		//check if any card on the table forms a pair with player hand
		//do not need to consider 3 or 4 of a kind because they are already checked before this occurs
		for (int i = 0; i < cardsInPlay.size(); i++) {
			if (cardsInPlay.get(i).face_value == BotActive.hand.get(0).face_value
					|| cardsInPlay.get(i).face_value == BotActive.hand.get(1).face_value) {
				//because a pair is a relatively week hand if the risk is too great then ignore the pair and 'fold' the hand
				if (potAmount < BotActive.balance / 5) {
					BotActive.bet = BotActive.balance / 10;
					BotActive.status = "raise";
					BotActive.handStrength = 1;
					return true;
				} else {
					BotActive.status = "fold";
					
					return true;
				}

			}

		}
		return false;
	}
}



