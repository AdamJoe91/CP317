package pokerAssistant;

import java.util.*;
import javax.swing.*;
import java.util.concurrent.TimeUnit;

// Each player is an object

public class Table {
	
	public static void main(String argsp[]) {
		// ================================  Setup Code  =====================================
		
		// Set starting funds for players
		float START_BALANCE = 1000;
		
		// Prevent duplicates by storing cards
		ArrayList<Card> cardsInPlay = new ArrayList<Card>();
		
		// Create player objects
		// Player(hand, Starting balance, bet,  isBig, isDeader, move)
		Player bot1 = new Player(new ArrayList<Card>(), START_BALANCE, 0, false, false, false, ""); 
		Player bot2 = new Player(new ArrayList<Card>(), START_BALANCE, 0, false, false, false, "");
		Player bot3 = new Player(new ArrayList<Card>(), START_BALANCE, 0, false, false, false, "");
		Player player = new Player(new ArrayList<Card>(), START_BALANCE, 0, false, false, false, "");
		Player prediction = new Player(new ArrayList<Card>(), START_BALANCE, 0, false, false, false, "");
		
		// Create a Player Object called 'table' to hold cards on table top
		Player table = new Player(new ArrayList<Card>(), 0, 0, false, false, false, "");
		
		// Order of play
		ArrayList<Player> OrderOfPlay = new ArrayList<Player>();
	
		// Deal cards
		player.add_card(cardsInPlay);
		bot1.add_card(cardsInPlay);
		bot2.add_card(cardsInPlay);
		bot3.add_card(cardsInPlay);
		
		// Assign prediction engine the same cards as the player
		prediction.hand = player.hand;
		
		// Add players to the OrderOfPlay
		OrderOfPlay.add(bot1);
		OrderOfPlay.add(bot2);
		OrderOfPlay.add(bot3);
		OrderOfPlay.add(player);
		
		// Open new instance of the table interface
		TableGUI.drawTable();
		
		// Draw CPU profile pictures
		TableGUI.setCPU(1,1);
		TableGUI.setCPU(2,2);
		TableGUI.setCPU(3,3);
		
		// Draw CPU and player balances
		TableGUI.setPot(0,0);				// Pot
		TableGUI.setPot(1,START_BALANCE);	// Bot 1
		TableGUI.setPot(2,START_BALANCE);	// Bot 2
		TableGUI.setPot(3,START_BALANCE);	// Bot 3
		TableGUI.setPot(4,START_BALANCE);	// Player
		
		// Draw Player Cards
		TableGUI.setCard(6,player.hand.get(0).suit + 1 ,player.hand.get(0).face_value + 1 );
		TableGUI.setCard(7,player.hand.get(1).suit + 1 ,player.hand.get(1).face_value + 1 );
		
		
		

		// =================================  Main Game Code  ================================
				
		Player currentPlayer = null;
		int turnNum = 0;
		int count;
		int round = 0;
		boolean betting = true;
		boolean endHand = false;
		Scanner userInput = new Scanner(System.in);		
		float pot = 0;
		float bet = 0;
		int numFolds = 0;
		String game = "not done";
		String option = "no";
		
		// Loop until game is finished
		while (!game.contentEquals("done")) {
		//	TableGUI.drawBotTurn() ;
			System.out.println("");  
			System.out.println("==================== *** NEW HAND *** ====================");
			
			round = 0;
			endHand = false;
		
			// Loop through all 5 betting rounds of 1 hand
			while ((round < 4) && (endHand == false)) {
				
				// Reset Counters
				turnNum = 0;
				count = 0;
				
				//TESTING
				System.out.println("");  
				System.out.println("==================== NEW BETTING ROUND ====================");
				System.out.println(""); 
				
				// Loop through each player's turn 
				betting = true;
				while (betting == true || count < OrderOfPlay.size()) {
					
					// Pause between turns
					try {
						TimeUnit.SECONDS.sleep(1);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					
					
					// If we have completed a loop of the table, reset the turnNum
					if (turnNum == OrderOfPlay.size()) {
						turnNum = 0;
					}
					
					// Set Current Player
					currentPlayer = OrderOfPlay.get(turnNum);
					
					
					// If its the player's turn
					if (currentPlayer == player && ! currentPlayer.status.contentEquals("fold") && currentPlayer.balance != 0) {
						
						System.out.print("PLAYER TURN: ");
						currentPlayer.print();
						prediction.balance = currentPlayer.balance;
						
						boolean betOK = false;
						
						// Get recommended move from prediction engine
						if (round == 0) {
							prediction.firstBotChoice(prediction, bet);
						} else {
							prediction.tableBotChoice(prediction, table.hand, pot, bet);
						}
						
						TableGUI.setRecommend(prediction.status);

//						// Do not get input if player is already allIn
//						if (currentPlayer.status.contentEquals("allIn")) {
//							betOK = true;
//							currentPlayer.status = "check";
//							currentPlayer.bet = 0;
//						}
						
						// Loop until correct input is entered
						while (betOK == false) {
							
							TableGUI.showOptions();
							option = "no";
							
							// Get input from user
							while (option.contentEquals("no")) {
								option = TableGUI.getOption(); 
								System.out.print("");
							}
							
							// Raise and allIn must be handled differently than other actions
							if (option.contentEquals("raise")) {
								currentPlayer.bet = TableGUI.getRaise();
								currentPlayer.status = "raise";
							} else {
								currentPlayer.status = option;
							}

							// Ensure action is valid
							if (currentPlayer.status.contentEquals("raise") && currentPlayer.bet < bet) {
								System.out.println("INVALID ACTION: raise too small");
								JOptionPane.showMessageDialog(null, "INVALID ACTION: \n You must raise more than the current highest bet", "INVALID ACTION", JOptionPane.INFORMATION_MESSAGE);
								
							} else if (currentPlayer.status.contentEquals("check") &&  currentPlayer.bet != bet) {
								System.out.println("INVALID ACTION: you must call/raise/fold/allIn");
								JOptionPane.showMessageDialog(null, "INVALID ACTION: \n You cannot check after another player has bet", "INVALID ACTION", JOptionPane.INFORMATION_MESSAGE);
								
							} else if (currentPlayer.status.contentEquals("call") &&  currentPlayer.balance < bet) {
								System.out.println("INVALID ACTION: insufficient funds to call");
								JOptionPane.showMessageDialog(null, "INVALID ACTION: You do not have enough money to call", "INVALID ACTION", JOptionPane.INFORMATION_MESSAGE);
								
							} else {
								betOK = true;
							}
							
							// Increment numFolds is the player folds
							if (currentPlayer.status.contentEquals("fold")) {
								numFolds++;
								currentPlayer.bet = 0;
							}
														
						}
						
						// Update player object to match input
						if (currentPlayer.status.contentEquals("call")) {
							currentPlayer.bet = bet;
						}
						if (currentPlayer.status.contentEquals("allIn")) {
							System.out.println(currentPlayer.status);
							currentPlayer.bet = currentPlayer.balance;
						}
						
						// Update prediction engine to match player object
						prediction.bet = currentPlayer.bet;
						prediction.status =  currentPlayer.status;
						
						
					// If its the bot's turn to play
					} else if ((!currentPlayer.status.contentEquals("fold")) && (currentPlayer.balance != 0)) {
						
						// Bots Class uses a separate function if the table is empty
						if (round == 0) {
							currentPlayer.firstBotChoice(currentPlayer, bet);
						} else {
							currentPlayer.tableBotChoice(currentPlayer, table.hand, pot, bet);
						}
						
						// Ensure action is valid (correct the bot to a valid move)
						if (currentPlayer.status.contentEquals("raise") && currentPlayer.bet < bet) {
							currentPlayer.status = "call";
							currentPlayer.bet = bet;
						}
						if (currentPlayer.status.contentEquals("check") &&  bet > 0) {
							currentPlayer.status = "call";
							currentPlayer.bet = bet;
						}
						if (currentPlayer.status.contentEquals("call") &&  currentPlayer.balance < bet + 1) { // <-- +1 stops bot from betting with 0 when highest bet is 0
							currentPlayer.status = "allIn";
							currentPlayer.bet = currentPlayer.balance;
						}
						if (currentPlayer.status.contentEquals("call")) {
							currentPlayer.bet = bet;
						}
						if (currentPlayer.status.contentEquals("call") && (currentPlayer.bet == 0)) {
							currentPlayer.status = "check";
						}
						if (currentPlayer.status.contentEquals("fold")) {
							numFolds++;
							currentPlayer.bet = 0;
						}
						
					} else if (!currentPlayer.status.contentEquals("fold")) {
						currentPlayer.status = "check";
						currentPlayer.bet = 0;
					}
					
					
					// Update highest bet
					if (currentPlayer.bet > bet) {
						bet = currentPlayer.bet;
					}
					
					// Update pot and GUI
					pot += currentPlayer.bet;
					TableGUI.setPot(0, pot);
					
					// Update player pot GUI
					TableGUI.setPot(turnNum + 1, currentPlayer.balance - currentPlayer.bet);
					
					// Determine if betting is finished
					betting = false;
					for (int i = 0; i < OrderOfPlay.size(); i++) {
						// For a hand to finish, each player must have the same investment into the pot
						if ((OrderOfPlay.get(i).bet != bet) && (!OrderOfPlay.get(i).status.contentEquals("fold")) && (OrderOfPlay.get(i).balance != 0)) {
							betting = true;
						} 
					}
					
					// If there is only one player left that hasn't folded, end the hand
					if (numFolds >= OrderOfPlay.size() - 1) {
						endHand = true;
						System.out.println("All but one player has folded --> ending hand");
					}
					
					// Update Balance
					currentPlayer.balance -= currentPlayer.bet;
					
					//testing
					System.out.println("Player " + turnNum + "  Status: " + currentPlayer.status + "  Current Bet:" + currentPlayer.bet + "   Total Pot: " + pot + "   Balance Remaining: " + currentPlayer.balance);
					
					// Increment Counters
					turnNum++;
					count++;
					
				} //  <-- This is the end of a betting round
				
				// Deal cards to table top
				if (round == 0) {
					table.hand.add(TableFunctions.dealCard(cardsInPlay));
					table.hand.add(TableFunctions.dealCard(cardsInPlay));
					table.hand.add(TableFunctions.dealCard(cardsInPlay));
					
					TableGUI.setCard(1,table.hand.get(0).suit + 1 ,table.hand.get(0).face_value + 1);
					TableGUI.setCard(2,table.hand.get(1).suit + 1 ,table.hand.get(1).face_value + 1);
					TableGUI.setCard(3,table.hand.get(2).suit + 1 ,table.hand.get(2).face_value + 1);
					
				} else if (round == 1) {
					table.hand.add(TableFunctions.dealCard(cardsInPlay));
					TableGUI.setCard(4,table.hand.get(3).suit + 1 ,table.hand.get(3).face_value + 1);
					
				} else if (round == 2) {
					table.hand.add(TableFunctions.dealCard(cardsInPlay));
					TableGUI.setCard(5,table.hand.get(4).suit + 1 ,table.hand.get(4).face_value + 1);
					
				} else {
					// No card is dealt after last hand
					
				}
				
				// Increment Counter
				round++;
				
				// Reset Bet
				bet = 0;
				
			} //   <-- This is the end of a hand
			
			
			
			// Determine Winner
			Player winner = null;
			int max = -1;
			for (int i = 0; i < OrderOfPlay.size(); i++) {
				if (OrderOfPlay.get(i).handStrength > max && OrderOfPlay.get(i).status.contentEquals("fold")) {
					winner = OrderOfPlay.get(i);
				}
			}
			
			// Tabulate winnings
			winner.balance += pot;
			
			// Reset pot
			pot = 0;
			
			// Update pot values (GUI)
			for (int i = 0; i < OrderOfPlay.size(); i++) {
				TableGUI.setPot(i + 1, OrderOfPlay.get(i).balance);
			}
			
			// Reset numFolds
			numFolds = 0;
			
			// Reset highest bet
			bet = 0;
			
			// Reset Game Board
			TableGUI.clearCards();
			
			// Update Pots**********
			TableGUI.setPot(0, 0);
			
			// Reset player statuses
			for (int i = 0; i < OrderOfPlay.size(); i++) {
				OrderOfPlay.get(i).status = "check";
			}
			
			// Clear cards from table
			cardsInPlay.clear();
			player.hand.clear();
			bot1.hand.clear();
			bot2.hand.clear();
			bot3.hand.clear();
			table.hand.clear();
			
			// Deal new cards
			player.add_card(cardsInPlay);
			bot1.add_card(cardsInPlay);
			bot2.add_card(cardsInPlay);
			bot3.add_card(cardsInPlay);
			
			// Draw new cards on screen
			TableGUI.setCard(6,player.hand.get(0).suit + 1 ,player.hand.get(0).face_value + 1 );
			TableGUI.setCard(7,player.hand.get(1).suit + 1 ,player.hand.get(1).face_value + 1 );
			
			// Reset the strength of each players hand
			player.handStrength = 0;
			bot1.handStrength = 0;
			bot2.handStrength = 0;
			bot3.handStrength = 0;
			
			// See if the game has ended
			int outOfMoney = 0;
			for (int i = 0; i < OrderOfPlay.size(); i++) {
				if (OrderOfPlay.get(i).balance == 0) {
					outOfMoney++;
				}
			}
			if (outOfMoney > OrderOfPlay.size() - 2) {
				game = "done";
			}
			
			
			
			} //  <-- End of Game
			
		// Close Input Scanner
		userInput.close();
		
	} 
	
}
