package pokerAssistant;
import java.util.ArrayList;

public class TableFunctions {
	
	
	public static Card dealCard(ArrayList <Card> cards_in_play) {
		/* =============================================================
		 * Generates a new, randomly selected card that is not already in
		 * circulation and deals it to the Player
		 * =============================================================
		 * Preconditions:
		 * 		cards_in_play - An ArrayList<Card> with all cards in 
		 * 						circulation
		 * 
		 * Postconditions:
		 * 		A card is added to both the players hand and the 
		 * 		cards_in_play list
		 * =============================================================
		 */ 
		
		// Instantiate Variables
		Card card = new Card(0, 0);
		int flag = 0;
		
		while (flag == 0) {
			// Get random suit and face
			int suit = 0 + (int)(Math.random() * 3);
			int face = 0 + (int)(Math.random() * 13);
			
			// Update card values
			card.suit = suit;
			card.face_value = face;
			
			// Check if cards_in_play is empty
			if (cards_in_play.size() == 0) {
				flag = 1;
				
			// If not empty, loop through cards_in_play
			} else {
				for (int i = 0; i < cards_in_play.size(); i++) {
					
					Card temp = cards_in_play.get(i);
					
					// Make sure the card hasn't been dealt
					if ((card.suit == temp.suit) & (card.face_value == temp.face_value)) {
						flag = 0;
					} else {
						flag = 1;
					}
				}
			}
		}
		
		cards_in_play.add(card);
		
		return card;
	}
	 
	
	
	
}

