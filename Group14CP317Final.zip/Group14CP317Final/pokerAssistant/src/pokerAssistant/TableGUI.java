/*
 * GUI for the Poker Assistant app.
 * 
 * Functions:
 * 
 * drawTable(): Initializes the blank table UI. Always use this first.
 * 
 * setCard(int,int,int): Modifies a card on the table.
 * 	-int 1 = card number (1-7) (6, 7 are player cards)
 * 	-int 2 = card suit (0-4)
 * 		0 = No suit/erase card suit
 * 		1 = club
 * 		2 = diamond
 * 		3 = heart
 * 		4 = spade
 * 	-int 3 = number on card (0-13)
 * 		0 = No number/erase card number
 * 		1 = Ace
 * 		2-10 = Rank
 * 		11 = Jack
 * 		12 = Queen
 * 		13 = King
 * 
 * setCPU(int, int): Modifies a CPU's avatar. In the future, 0 will represent no player.
 * 	-int 1 = CPU number (1-3)
 * 	-int 2 = Avatar number (1-3)
 * 
 * setPot(int, int): Sets the value of a pot.
 * 	-int 1 = Pot ID (0-3)
 * 		0 = Pot
 * 		1 = CPU1 Pot
 * 		2 = CPU2 Pot
 * 		3 = CPU3 Pot
 * 		4 = Player Pot
 * 	-int 2 = Value to set
 * 
 * addPot(int, int): Adds a value to a pot.
 * 	-int 1 = Pot ID (0-3)
 * 		0 = Pot
 * 		1 = CPU1 Pot
 * 		2 = CPU2 Pot
 * 		3 = CPU3 Pot
 * 		4 = Player Pot
 * 	-int 2 = Value to add
 * 	
 * subPot(int, int): Subtracts a value to a pot.
 * 	-int 1 = Pot ID (0-3)
 * 		0 = Pot
 * 		1 = CPU1 Pot
 * 		2 = CPU2 Pot
 * 		3 = CPU3 Pot
 * 		4 = Player Pot
 * 	-int 2 = Value to subtract
 * 
 * clearTable(): Clears the table of all values.
 * 
 * clearTableCPU(): Same as clearTable(), but also clears all avatars. Currently the same as clearTable().
 * 
 * clearCards(): Clears all cards from the table.
 * 
 * setTabe(): Refreshes the table GUI to update it with new info. Used by all other functions automatically.
 * 
 */


package pokerAssistant;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.*;
import java.io.*;
import javax.imageio.*;
import java.lang.Object;
import javax.swing.*;
import java.text.DecimalFormat;

public class TableGUI extends JPanel{
	
	private static DecimalFormat df2 = new DecimalFormat("#.##");
	
	static JFrame f = new JFrame("Table");
	static JFrame r = new JFrame("Actions");
	static JFrame rai = new JFrame("Raise");
	static JPanel table = new JPanel();
	static JPanel options = new JPanel();
	static JPanel options2 = new JPanel();
	static JPanel options3 = new JPanel();
	static JPanel options4 = new JPanel();
	static JPanel optionsR = new JPanel();
	static JPanel raiseMenu = new JPanel();
	static JTextField raiseVal = new JTextField();
	static JButton fold = new JButton("Fold");
	static JButton call = new JButton("Call");
	static JButton check = new JButton("Check");
	static JButton raise = new JButton("Raise");
	static JButton allIn = new JButton("All-In");
	static JButton raiseConfirm = new JButton("Confirm");
	static JButton showcommands = new JButton("Show Actions");
	static BufferedImage img1 = null;
	static BufferedImage img2 = null;
	static BufferedImage img3 = null;
	static BufferedImage img4 = null;
	static BufferedImage img5 = null;
	static BufferedImage imgP1 = null;
	static BufferedImage imgP2 = null;
	static BufferedImage imgTable = null;
	static BufferedImage recommended = null;
	static String num1 = "";
	static String num2 = "";
	static String num3 = "";
	static String num4 = "";
	static String num5 = "";
	static String numP1 = "";
	static String numP2 = "";
	static String recommend = "";
	static String option = "";
	static float raiseBy = 0;
	static float pot = 0;
    static Color suitC1 = Color.BLACK;
    static Color suitC2 = Color.BLACK;
    static Color suitC3 = Color.BLACK;
    static Color suitC4 = Color.BLACK;
    static Color suitC5 = Color.BLACK;
    static Color suitCP1 = Color.BLACK;
    static Color suitCP2 = Color.BLACK;
	static BufferedImage cpu1 = null;
	static BufferedImage cpu2 = null;
	static BufferedImage cpu3 = null;
	static float cpu1Pot = 0;
	static float cpu2Pot = 0;
	static float cpu3Pot = 0;
	static float playerPot = 0;
	
	public static JFrame drawTable() {
		
		try {
		    imgTable = ImageIO.read(new File(System.getProperty("user.dir")+"\\src\\resources\\table.png"));
		} catch (IOException e) {
		}
	    //System.out.println(System.getProperty("user.dir")+"\\src\\resources\\table.png");
		
		final BufferedImage image = imgTable;
		
        table = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(image, 0, 0, null);
            }
        };

        fold.addActionListener(new ActionListener()
        {
          public void actionPerformed(ActionEvent e)
          {
        	  option = returnAction("fold");
     		 r.setVisible(false);
          }
        });
        call.addActionListener(new ActionListener()
        {
          public void actionPerformed(ActionEvent e)
          {
        	  option = returnAction("call");
      		 r.setVisible(false);
          }
        });
        check.addActionListener(new ActionListener()
        {
          public void actionPerformed(ActionEvent e)
          {
        	  option = returnAction("check");
      		 r.setVisible(false);
          }
        });
        
        raise.addActionListener(new ActionListener()
        {
          public void actionPerformed(ActionEvent e)
          {
         	raiseVal.setText("0"); 
            rai.setVisible(true);
          }
        });
        raiseConfirm.addActionListener(new ActionListener()
        {
          public void actionPerformed(ActionEvent e)
          {
         	raise();
          	option = returnAction("raise");
         	rai.setVisible(false);
    		 r.setVisible(false);
          }
        });
        allIn.addActionListener(new ActionListener()
        {
          public void actionPerformed(ActionEvent e)
          {
            option = returnAction("allIn");
   		 	r.setVisible(false);
          }
        });
        
        showcommands.addActionListener(new ActionListener()
        {
          public void actionPerformed(ActionEvent e)
          {
          	 option = "no";
             r.setVisible(true);
          }
        });
        
		try {
		    recommended = ImageIO.read(new File(System.getProperty("user.dir")+"\\src\\resources\\r.png"));
		} catch (IOException e) {
		}
        //r.setLayout(new GridLayout(5,3,5,5)); 
        //r.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
        options2.setLayout(new GridLayout(5,3,1,1)); 
        options2.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
        options3.setLayout(new GridLayout(5,3,1,1)); 
        options3.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
        f.add(table, BorderLayout.CENTER);
        options.add(showcommands, BorderLayout.SOUTH);
        f.add(options, BorderLayout.SOUTH);
        options2.add(fold); 
        options2.add(call); 
        options2.add(check);
        options2.add(raise);
        options2.add(allIn); 
        options2.add(allIn); 
        options4.add(options2, BorderLayout.CENTER);
        //options4.add(options3, BorderLayout.EAST);
        setRecommended();
        r.add(options4, BorderLayout.EAST);
        r.add(optionsR, BorderLayout.CENTER);
        options.setBackground(new Color(0,125,60));
        options2.setBackground(new Color(0,125,60));
        options3.setBackground(new Color(0,125,60));
        options4.setBackground(new Color(0,125,60));
        showcommands.setBackground(new Color(197,181,3));
        fold.setBackground(new Color(197,181,3));
        call.setBackground(new Color(197,181,3));
        check.setBackground(new Color(197,181,3));
        raise.setBackground(new Color(197,181,3));
        allIn.setBackground(new Color(197,181,3));
        raiseMenu.setBackground(new Color(0,125,60));
        raiseVal.setBackground(new Color(197,181,3));
        raiseConfirm.setBackground(new Color(197,181,3));
        raiseMenu.add(raiseVal, BorderLayout.NORTH);
        raiseMenu.add(raiseConfirm, BorderLayout.SOUTH);
        r.setBackground(new Color(197,181,3));
        f.setBackground(new Color(197,181,3));
        f.setSize(645, 545); 
        r.setSize(344, 216); 
        rai.setSize(230, 90);
        raiseVal.setPreferredSize( new Dimension( 100, 20 ) );
        rai.add(raiseMenu, BorderLayout.CENTER);
        f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        f.setVisible(true); 
        //r.setVisible(true); 
		
        return f;
	}
	
	public static JFrame setCard(int cardNum, int suit, int num) {
		
		String suitS = "";
		
			switch(suit) {
			case 0:
				suitS = "";
				break;
			case 1:
				suitS = "club";
				break;
			case 2:
				suitS = "diamond";
				break;
			case 3:
				suitS = "heart";
				break;
			case 4:
				suitS = "spade";
				break;
			}
		
	    switch(cardNum) {
	    case 1:
	    	try {
	    		if(suit != 0)
	    			img1 = ImageIO.read(new File(System.getProperty("user.dir")+"\\src\\resources\\"+suitS+".png"));
	    		else
	    			img1 = null;
	    	} catch (IOException e) {
			}
		    if (suit == 2 || suit == 3)
		    	suitC1 = Color.RED;
		    else
		    	suitC1 = Color.BLACK;
	    	switch (num) {
	    	case 0:
	    		num1 = "";
	    		break;
	    	case 1:
	    		num1 = "A";
	    		break;
	    	case 11:
	    		num1 = "J";
	    		break;
	    	case 12:
	    		num1 = "Q";
	    		break;
	    	case 13:
	    		num1 = "K";
	    		break;
	    	default:
		    	num1 = Integer.toString(num);
		    	break;
	    	}
	    	break;
	    case 2:
	    	try {
	    		if(suit != 0)
	    			img2 = ImageIO.read(new File(System.getProperty("user.dir")+"\\src\\resources\\"+suitS+".png"));
	    		else
	    			img2 = null;
	    	} catch (IOException e) {
			}
		    if (suit == 2 || suit == 3)
		    	suitC2 = Color.RED;
		    else
		    	suitC2 = Color.BLACK;
	    	switch (num) {
	    	case 0:
	    		num2 = "";
	    		break;
	    	case 1:
	    		num2 = "A";
	    		break;
	    	case 11:
	    		num2 = "J";
	    		break;
	    	case 12:
	    		num2 = "Q";
	    		break;
	    	case 13:
	    		num2 = "K";
	    		break;
	    	default:
		    	num2 = Integer.toString(num);
		    	break;
	    	}
	    	break;
	    case 3:
	    	try {
	    		if(suit != 0)
	    			img3 = ImageIO.read(new File(System.getProperty("user.dir")+"\\src\\resources\\"+suitS+".png"));
	    		else
	    			img3 = null;
	    	} catch (IOException e) {
			}
		    if (suit == 2 || suit == 3)
		    	suitC3 = Color.RED;
		    else
		    	suitC3 = Color.BLACK;
	    	switch (num) {
	    	case 0:
	    		num3 = "";
	    		break;
	    	case 1:
	    		num3 = "A";
	    		break;
	    	case 11:
	    		num3 = "J";
	    		break;
	    	case 12:
	    		num3 = "Q";
	    		break;
	    	case 13:
	    		num3 = "K";
	    		break;
	    	default:
		    	num3 = Integer.toString(num);
		    	break;
	    	}
	    	break;
	    case 4:
	    	try {
	    		if(suit != 0)
	    			img4 = ImageIO.read(new File(System.getProperty("user.dir")+"\\src\\resources\\"+suitS+".png"));
	    		else
	    			img4 = null;
	    	} catch (IOException e) {
			}
		    if (suit == 2 || suit == 3)
		    	suitC4 = Color.RED;
		    else
		    	suitC4 = Color.BLACK;
	    	switch (num) {
	    	case 0:
	    		num4 = "";
	    		break;
	    	case 1:
	    		num4 = "A";
	    		break;
	    	case 11:
	    		num4 = "J";
	    		break;
	    	case 12:
	    		num4 = "Q";
	    		break;
	    	case 13:
	    		num4 = "K";
	    		break;
	    	default:
		    	num4 = Integer.toString(num);
		    	break;
	    	}
	    	break;
	    case 5:
	    	try {
	    		if(suit != 0)
	    			img5 = ImageIO.read(new File(System.getProperty("user.dir")+"\\src\\resources\\"+suitS+".png"));
	    		else
	    			img5 = null;
	    	} catch (IOException e) {
			}
		    if (suit == 2 || suit == 3)
		    	suitC5 = Color.RED;
		    else
		    	suitC5 = Color.BLACK;
	    	switch (num) {
	    	case 0:
	    		num5 = "";
	    		break;
	    	case 1:
	    		num5 = "A";
	    		break;
	    	case 11:
	    		num5 = "J";
	    		break;
	    	case 12:
	    		num5 = "Q";
	    		break;
	    	case 13:
	    		num5 = "K";
	    		break;
	    	default:
		    	num5 = Integer.toString(num);
		    	break;
	    	}
	    	break;
	    case 6:
	    	try {
	    		if(suit != 0)
	    			imgP1 = ImageIO.read(new File(System.getProperty("user.dir")+"\\src\\resources\\"+suitS+".png"));
	    		else
	    			imgP1 = null;
	    	} catch (IOException e) {
			}
		    if (suit == 2 || suit == 3)
		    	suitCP1 = Color.RED;
		    else
		    	suitCP1 = Color.BLACK;
	    	switch (num) {
	    	case 0:
	    		numP1 = "";
	    		break;
	    	case 1:
	    		numP1 = "A";
	    		break;
	    	case 11:
	    		numP1 = "J";
	    		break;
	    	case 12:
	    		numP1 = "Q";
	    		break;
	    	case 13:
	    		numP1 = "K";
	    		break;
	    	default:
		    	numP1 = Integer.toString(num);
		    	break;
	    	}
		    break;
	    case 7:
	    	try {
	    		if(suit != 0)
	    			imgP2 = ImageIO.read(new File(System.getProperty("user.dir")+"\\src\\resources\\"+suitS+".png"));
	    		else
	    			imgP2 = null;
	    	} catch (IOException e) {
			}
		    if (suit == 2 || suit == 3)
		    	suitCP2 = Color.RED;
		    else
		    	suitCP2 = Color.BLACK;
	    	switch (num) {
	    	case 0:
	    		numP2 = "";
	    		break;
	    	case 1:
	    		numP2 = "A";
	    		break;
	    	case 11:
	    		numP2 = "J";
	    		break;
	    	case 12:
	    		numP2 = "Q";
	    		break;
	    	case 13:
	    		numP2 = "K";
	    		break;
	    	default:
		    	numP2 = Integer.toString(num);
		    	break;
	    	}
		    break;
	    }
	    
	    	
		
		//System.out.println(System.getProperty("user.dir")+"\\src\\resources\\"+suitS+".png");
		
        setTable();
        
        f.remove(table);
        f.add(table, BorderLayout.CENTER); 
        f.setVisible(true);
		
        return f;
	}
	
	public static JFrame setCPU(int cpuNum, int charNum) {
		
	    switch(cpuNum) {
	    case 1:
	    	try {
				cpu1 = ImageIO.read(new File(System.getProperty("user.dir")+"\\src\\resources\\players\\"+Integer.toString(charNum)+".png"));
			} catch (IOException e) {
			};
	    	break;
	    case 2:
	    	try {
				cpu2 = ImageIO.read(new File(System.getProperty("user.dir")+"\\src\\resources\\players\\"+Integer.toString(charNum)+".png"));
			} catch (IOException e) {
			};
	    	break;
	    case 3:
	    	try {
				cpu3 = ImageIO.read(new File(System.getProperty("user.dir")+"\\src\\resources\\players\\"+Integer.toString(charNum)+".png"));
			} catch (IOException e) {
			};
	    	break;
	    }
	    //System.out.println(System.getProperty("user.dir")+"\\src\\resources\\table.png");
	    
        setTable();
		
        return f;
	}
	
	public static JFrame setPot(int playerNum, float pot2) {
		
	    switch(playerNum) {
	    case 0:
	    	pot = pot2;
	    	break;
	    case 1:
	    	cpu1Pot = pot2;
	    	break;
	    case 2:
	    	cpu2Pot = pot2;
	    	break;
	    case 3:
	    	cpu3Pot = pot2;
	    	break;
	    case 4:
	    	playerPot = pot2;
	    }
	    
        setTable();
		
        return f;
	}
	
	public static JFrame addPot(int playerNum, float pot2) {
		
	    switch(playerNum) {
	    case 0:
	    	pot += pot2;
	    	break;
	    case 1:
	    	cpu1Pot += pot2;
	    	break;
	    case 2:
	    	cpu2Pot += pot2;
	    	break;
	    case 3:
	    	cpu3Pot += pot2;
	    	break;
	    case 4:
	    	playerPot += pot2;
	    }
	    
        setTable();
		
        return f;
	}
	
	public static JFrame subPot(int playerNum, float pot2) {
		
	    switch(playerNum) {
	    case 0:
	    	pot -= pot2;
	    	break;
	    case 1:
	    	cpu1Pot -= pot2;
	    	break;
	    case 2:
	    	cpu2Pot -= pot2;
	    	break;
	    case 3:
	    	cpu3Pot -= pot2;
	    case 4:
	    	playerPot -= pot2;
	    	break;
	    }
	    
        setTable();
		
        return f;
	}
	
	public static JFrame clearTable() {
		
	    setPot(0,0);
	    setPot(1,0);
	    setPot(2,0);
	    setPot(3,0);
	    setCard(1,0,0);
	    setCard(2,0,0);
	    setCard(3,0,0);
	    setCard(4,0,0);
	    setCard(5,0,0);
	    
        setTable();
		
        return f;
	}
	
public static JFrame clearTableCPU() {
		
	    setPot(0,0);
	    setPot(1,0);
	    setPot(2,0);
	    setPot(3,0);
	    setCard(1,0,0);
	    setCard(2,0,0);
	    setCard(3,0,0);
	    setCard(4,0,0);
	    setCard(5,0,0);
	    setCPU(1,0);
	    setCPU(2,0);
	    setCPU(3,0);
	    
        setTable();
		
        return f;
	}
public static JFrame clearCards() {
	
    setCard(1,0,0);
    setCard(2,0,0);
    setCard(3,0,0);
    setCard(4,0,0);
    setCard(5,0,0);
    
    setTable();
	
    return f;
}
	
	public static JFrame setTable() {
		table = new JPanel() {
            //@Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(imgTable, 0, 0, null);
                g.drawImage(img1, 130, 328, null);
                g.drawImage(img2, 205, 328, null);
                g.drawImage(img3, 280, 328, null);
                g.drawImage(img4, 355, 328, null);
                g.drawImage(img5, 430, 328, null);
                g.drawImage(imgP1, 422, 180, null);
                g.drawImage(imgP2, 497, 180, null);
                g.drawImage(cpu1, 33, 0, null);
                g.drawImage(cpu2, 280, 0, null);
                g.drawImage(cpu3, 520, 0, null);
                
                g.setFont(new Font("TimesRoman", Font.PLAIN, 50)); 
                g.setColor(suitC1);
                g.drawString(num1, 145, 392); 
                g.setColor(suitC2);
                g.drawString(num2, 220, 392);
                g.setColor(suitC3);
                g.drawString(num3, 295, 392);
                g.setColor(suitC4);
                g.drawString(num4, 370, 392);
                g.setColor(suitC5);
                g.drawString(num5, 445, 392);
                g.setColor(suitCP1);
                g.drawString(numP1, 437, 244);
                g.setColor(suitCP2);
                g.drawString(numP2, 512, 244);
                g.setFont(new Font("TimesRoman", Font.PLAIN, 30)); 
                g.setColor(Color.BLACK);
                
                
                
                g.drawString(df2.format(cpu1Pot), 23, 115); 
                g.drawString(df2.format(cpu2Pot), 270, 115); 
                g.drawString(df2.format(cpu3Pot), 510, 115); 
                g.drawString(df2.format(playerPot), 86, 276); 
                g.setFont(new Font("TimesRoman", Font.PLAIN, 40)); 
                g.drawString(df2.format(pot), 260, 245); 
                g.setFont(new Font("TimesRoman", Font.PLAIN, 20)); 
        	
            }
        };
        
        f.remove(table);
        f.add(table, BorderLayout.CENTER); 
        f.setVisible(true);
        
		return f;
	}
	
	public static JFrame setRecommended() {
		optionsR = new JPanel() {
            //@Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(recommended, 0, 0, null);
                g.setFont(new Font("TimesRoman", Font.PLAIN, 40)); 
                g.setColor(Color.BLACK);
                g.drawString(recommend, 70, 125);
            }
        };
        
        r.remove(optionsR);
        r.add(optionsR, BorderLayout.CENTER); 
        //r.setVisible(true);
        
		return r;
	}
	
	public static String returnAction(String action) {
		 return action;
	}
	
	public static void setRecommend(String recommend2) {
		 recommend = recommend2;
		 setRecommended();
	}
	public static float raise() {
		raiseBy = Float.parseFloat(raiseVal.getText());
		raiseVal.setText("0");
		rai.setVisible(false);
		return raiseBy;
	}
	
	public static void setOption(String option2) {
		 option = option2;
	}
	
	public static String getOption() {
		 return option;
	}
	
	public static void showOptions() {
		 option = "no";
		 r.setVisible(true);
	}
	
	public static float getRaise() {
		 return raiseBy;
	}
		



	
	
	public static void drawPlayerTurn() {
		
	}
}
